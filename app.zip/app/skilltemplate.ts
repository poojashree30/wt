export class skilltemplate {
    public username : string;
    public skills : string[];
    

    constructor(username : string, skills :string[]){
        this.username = username;
        this.skills = skills;
    }
}